module.exports = {
    left: "left", //
    right: "right",
    down: "down",
    up: "up",
    weapons: "weapons",//切花武器
}