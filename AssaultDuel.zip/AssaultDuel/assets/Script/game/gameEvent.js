module.exports = {
    /*****加载场景*/
    load_scene: "load_scene",
    /*****弹出一个预制体*/
    popup_prefab: "popup_prefab",
    /*****关闭一个预制体*/
    closed_prefab: "closed_prefab",
    /*****向左移动*/
    moveLeft: "moveLeft",
}