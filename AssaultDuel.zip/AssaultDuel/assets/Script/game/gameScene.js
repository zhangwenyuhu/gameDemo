module.exports = {
    hall: "hall",
    gameGuanka:"gameGuanka",
    gameMain: "gameMain",
    mapEdit: "mapEdit",
    roleEdit: "roleEdit",
}