cc.Class({
    extends: cc.Component,
    properties: {},
    onDestroy() {
    },
    onLoad() {
        cc.log(new sp.spine.Vector2(1, 2));
    },
    start() {
    },
    // update (dt) {},
});
