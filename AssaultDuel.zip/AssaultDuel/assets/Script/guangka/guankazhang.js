cc.Class({
    extends: cc.Component,
    properties: {
        num: 1
    },
    onDestroy() {
    },
    onLoad() {
    },
    // LIFE-CYCLE CALLBACKS:
    //当该组件被启用，并且它的节点也激活时。
    // onEnable() {
    // },
    // //当该组件被禁用或节点变为无效时调用。
    // onDisable() {
    // },
    //该方法为生命周期方法，父类未必会有实现。
    start() {
    },
    // update (dt) {},
});
