let PoolComponent = require("PoolComponent"); //池子组件
cc.Class({
    extends: PoolComponent,
    properties: {},
    //受到的伤害
    onHurt(value) {
    }
});
