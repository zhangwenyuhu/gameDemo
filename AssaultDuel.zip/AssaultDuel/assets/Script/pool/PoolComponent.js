cc.Class({
    extends: cc.Component,
    properties: {},
    //回收
    unuse: function () {
    },
    //重用
    reuse: function (data) {
    },
    onComplete: function () {
    }
});
