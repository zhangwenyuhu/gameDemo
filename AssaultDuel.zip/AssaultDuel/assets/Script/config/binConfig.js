module.exports = {
    "junguan": {
        hp: 300,
        attack: 40,
        findX: 40
    }
}