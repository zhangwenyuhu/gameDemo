module.exports = {
    gameOver_loss:  {
        url:  "/ui/gameOver_loss"
    },
    gameOver_win:  {
        url:  "/ui/gameOver_win"
    },
    gamePause:  {
        url:  "/ui/gamePause"
    }
}