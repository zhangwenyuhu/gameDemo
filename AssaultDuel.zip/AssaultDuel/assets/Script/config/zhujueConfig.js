module.exports = {
    hp: 300000, //初始血量
    "1": {
        name: "weapons1", //武器皮肤名称
        rotation: 20,
        sendTime: 0.3,//子弹发射时间
        attackId: 1,//攻击动作id
        attack: 10,//攻击力
        bid: 1,
        aimY: 0
    },//手枪
    "2": {
        name: "weapons2",
        rotation: 22,
        sendTime: 0.6,
        attackId: 2,
        attack: 3000,
        bid: 1,
        aimY: 0
    },//来福枪
    "3": {
        name: "weapons3",
        rotation: 25,
        sendTime: 0.6,
        attackId: 2,
        attack: 120, //
        bid: 1,
        aimY: -50
    },//闪电枪
    "4": {
        name: "weapons4",
        rotation: 25,
        sendTime: 0.6, //子弹发射时间
        attackId: 2,   //攻击动作id
        attack: 180,  //攻击力
        bid: 1,       //子弹id
        aimY: 0
    }//火箭筒
};