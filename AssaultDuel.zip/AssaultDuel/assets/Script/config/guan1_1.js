module.exports = {
    de_bu: { //德国小兵
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    de_jun: { //德国军官
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    de_pao: { //德国炮兵
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    hanjian: { //汉奸
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    rb_bu: { //日本步兵
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    rb_qi: { //日本骑兵
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    rb_quan: { //日本拳手
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    rb_zu: { //日本阻击兵
        hp: 3000,
        attack: 40,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    rb_wu: { //日本阻击兵
        hp: 3000,
        attack: 140,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    bl_man: { //bolo 男
        hp: 3000,
        attack: 140,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
    bl_woman: { //bolo 男
        hp: 3000,
        attack: 140,
        findX: 40,
        count: 10,
        shootLen: 1000 //子弹射程
    },
}