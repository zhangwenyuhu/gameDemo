module.exports = {
    guan1_1: { //第一章 第一关配置
        "junguan": {
            hp: 300,
            attack: 40,
            findX: 40
        },
    }
}