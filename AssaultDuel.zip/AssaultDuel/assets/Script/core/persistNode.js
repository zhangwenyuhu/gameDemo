cc.Class({
    extends: cc.Component,
    //常驻节点 UI 层
    // 资源加载层
    properties: {},
    onLoad() {

    },
    start() {
    },
    onDestroy() {
    },

    // update (dt) {},
});
